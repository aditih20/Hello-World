/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
		System.out.println("My name is Aditi");
		System.out.println("I am in 12th grade");
		System.out.println("I enjoy working out, hiking, and traveling when I get the chance");
		System.out.println("I know how to code in Python so I am interested in learning Java");
		System.out.println("I like the colors green, black, and grey");
	}
}
